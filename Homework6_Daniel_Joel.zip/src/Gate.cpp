#include "Gate.h"

void Gate::setOut(int newValue, int setTime)
{
	out->setValue(newValue, setTime);
}
